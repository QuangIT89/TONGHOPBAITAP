import pandas as pd

ser = pd.Series(5, index=[1, 2, 3, 4, 5])
print(ser)

# Output:
#
# 1    5
# 2    5
# 3    5
# 4    5
# 5    5
# dtype: int64