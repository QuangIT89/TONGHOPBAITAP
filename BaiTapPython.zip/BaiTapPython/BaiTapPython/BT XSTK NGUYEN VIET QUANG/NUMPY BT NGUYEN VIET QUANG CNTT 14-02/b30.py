import numpy as np

e = np.random
e.seed(10)

print("e rand: ", e.rand())

#kq: e rand:  0.771320643266746
