import numpy as np

g = np.random
g.seed(10)

print("g rand: ", g.rand())

#kq: g rand:  0.771320643266746
