import numpy as np

freetuts_ages = [19, 33, 51, 22, 18, 13, 45, 24, 58, 11, 25, 27, 26, 29]

print("Phương sai: ", np.var(freetuts_ages))
print("Độ lệch chuẩn: ", np.std(freetuts_ages))

#kq: Phương sai:  178.51530612244895
#    Độ lệch chuẩn:  13.360962020844493
