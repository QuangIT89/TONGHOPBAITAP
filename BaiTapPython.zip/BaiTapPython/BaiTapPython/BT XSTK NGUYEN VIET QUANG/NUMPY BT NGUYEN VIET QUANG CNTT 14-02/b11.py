import numpy as np
print("mean = ", np.mean(x))
print("median = ", np.median(x))