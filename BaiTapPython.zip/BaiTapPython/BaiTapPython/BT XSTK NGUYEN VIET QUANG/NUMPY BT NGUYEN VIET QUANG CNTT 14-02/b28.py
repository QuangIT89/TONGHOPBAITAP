import numpy as np

a = np.random.rand()
b = np.random.rand(4)  # Mảng có 1x8 phần tử
c = np.random.rand(2, 3)  # Mảng có 2x3 phần tử

print("a = ", a)
print("b = ", b)
print("c = ", c)

#kq: a =  0.4518437541802437
# b =  [0.22307635 0.32059432 0.42502901 0.39696883]
# c =  [[6.09694378e-01 6.28564569e-01 9.18077297e-04]
# [4.07400703e-01 9.96184498e-01 9.97447153e-01]]
