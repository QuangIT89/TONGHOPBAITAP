import numpy as np
coins = np.random.randint(2, size=1000)
print(coins.shape) 