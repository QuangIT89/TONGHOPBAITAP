import numpy as np
p = np.random.permutation(10)
print(p)

#kq: [5 6 8 4 7 0 2 1 3 9]
