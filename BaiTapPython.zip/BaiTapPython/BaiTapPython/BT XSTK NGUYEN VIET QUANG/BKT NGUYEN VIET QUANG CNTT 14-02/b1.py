num1 = input()
num2 = input()
if num1 > num2:
    print("num1 > num2")
else:
    print("num1 < num2")