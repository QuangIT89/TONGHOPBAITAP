import matplotlib.pyplot as plt
import numpy as np

plt.plot([1,2,3,4],[1,4,9,16],"go")
plt.xlabel("X label")
plt.ylabel("Y label")
plt.show()